from flask import Flask
from flask_script import Manager
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, url_for, render_template, redirect


app = Flask(__name__)  # 创建一个Flask app对象
# 数据库链接的配置，此项必须，格式为（数据库+驱动://用户名:密码@数据库主机地址:端口/数据库名称）
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:d123456@106.15.237.25:3306/test?charset=UTF8MB4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # 跟踪对象的修改，在本例中用不到调高运行效率，所以设置为False
db = SQLAlchemy(app=app)  # 为哪个Flask app对象创建SQLAlchemy对象，赋值为db
manager = Manager(app=app)  # 初始化manager模块



class Student(db.Model):  # 继承SQLAlchemy.Model对象，一个对象代表了一张表
    id= db.Column(db.Integer, primary_key=True, autoincrement=True, unique=True)  # id 整型，主键，自增，唯一
    num = db.Column(db.Integer, default=20)  # 学号 整型，默认为20
    name = db.Column(db.String(20))  # 名字 字符串长度为20
    school=db.Column(db.String(50))  # 学校 字符串长度为50

    __tablename__ = 'student'  # 该参数可选，不设置会默认的设置表名，如果设置会覆盖默认的表名
    def __init__(self, num,name, school):  # 初始化方法，可以对对象进行创建
        self.num = num
        self.name = name
        self.school=school

    def __repr__(self):  # 输出方法，与__str__类似，但是能够重现它所代表的对象
        return '<Student %r, %r, %r>' % (self.id,self.num, self.name, self.school)


@app.before_first_request
def create_db():
    # Recreate database each time for demo
    db.drop_all()
    db.create_all()
    stu = Student(1,'张三', '同济大学')
    db.session.add(stu)
    stuother = [Student(2,'李四', '科技大学'),
               Student(3,'王五', '北京大学'),
               Student(4,'丁六', '人才大学'),
               Student(5,'仲八', '清华大学')]
    db.session.add_all(stuother)
    db.session.commit()



@app.route('/studentlist',methods=['GET', 'POST'])
def userslist():
    sql = 'select * from student;'
    stu = db.session.execute(sql)
    print(stu)
    return render_template('liststudent.html', stu=stu)



if __name__ == '__main__':
    manager.run()  # 运行服务器